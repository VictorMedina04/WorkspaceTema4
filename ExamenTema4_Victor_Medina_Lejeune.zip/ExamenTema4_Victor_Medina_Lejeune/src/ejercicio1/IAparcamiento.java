package ejercicio1;

public interface IAparcamiento {

	public double calcularPrecio(double precioMinutos);
}
